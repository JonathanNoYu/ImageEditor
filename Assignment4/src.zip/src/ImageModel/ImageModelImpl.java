package ImageModel;

import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class ImageModelImpl implements ImageModel {
  private File in; // Current loaded image
  private final Map<String, File> storedFiles = new HashMap<>(); // Stored any files
  private Scanner scanFile;
  private int height;
  private int width;
  private int maxValue;

  @Override
  public void loadImage(String path, String imgName) {
    try {
      scanFile = new Scanner(new FileInputStream(path));
    } catch (FileNotFoundException e) {
      System.out.println("File " + imgName + " not found!");
      return;
    }

    StringBuilder builder = new StringBuilder();
    //read the file line by line, and populate a string. This will throw away any comment lines
    while (scanFile.hasNextLine()) {
      String s = scanFile.nextLine();
      if (s.charAt(0) != '#') {
        builder.append(s + System.lineSeparator());
      }
    }

    //now set up the scanner to read from the string we just built
    scanFile = new Scanner(builder.toString());

    String token;

    token = scanFile.next();
    if (!token.equals("P3")) {
      System.out.println("Invalid PPM file: plain RAW file should begin with P3");
    }
    this.width = scanFile.nextInt();
    this.height = scanFile.nextInt();
    this.maxValue = scanFile.nextInt();
  }

  @Override
  public void saveImage(String path, String destName) {
    try {
      File fromStorage = storedFiles.get(destName);
      Scanner readFile = new Scanner(fromStorage);
      DataOutputStream outputFile = new DataOutputStream(new FileOutputStream(path));
      while (readFile.hasNext()) { // while there is stuff in the file
        outputFile.write(readFile.nextByte()); // it writes into the new file being outputted
      }
      outputFile.close();
    } catch (IOException e) {
      System.out.println("File failed to save");
    }
  }
}
