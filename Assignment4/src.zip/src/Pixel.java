/**
 * A class that represents a single pixel, it is a simple object with three fields, one for each RBG
 * color and can do basic operations on those three components of a pixel.
 */
public class Pixel {

  private int red;
  private int green;
  private int blue;

  /**
   * The Main and Only constructor for a pixel, where all the components are from 0 to 255.
   * @param r is the value of the red component of this pixel
   * @param g is the value of the green component of this pixel
   * @param b is the value of the blue component of this pixel
   */
  public Pixel(int r, int g, int b) {
    if (r < 0 || g < 0 || b < 0
        || r > 255 || g < 255 || b < 255) { // prim data types can never be null
      throw new IllegalArgumentException("Pixels must have RGB values from 0 to 255");
    }
    this.red = r;
    this.green = g;
    this.blue = b;
  }

  public void setRed(int r) {
    if (r < 0 || r > 255) {
      throw new IllegalArgumentException("Red component can only be from 0 to 255");
    }
    this.red = r;
  }

  public void setGreen(int g) {
    if (g < 0 || g > 255) {
      throw new IllegalArgumentException("Green component can only be from 0 to 255");
    }
    this.green = g;
  }

  public void setBlue(int b) {
    if (b < 0 || b > 255) {
      throw new IllegalArgumentException("Blue component can only be from 0 to 255");
    }
    this.blue = b;
  }

  public int getRed() {
    return this.red;
  }

  public int getGreen() {
    return this.green;
  }

  public int getBlue() {
    return this.blue;
  }

  public int value() {
    return Math.max(Math.max(this.red, this.green), this.blue);
  }

  public int intensity() {
    return (this.red + this.green + this.blue) / 3;
  }

  public int luma() {
   return (int) ((0.2126 * this.red) + (0.7152 * this.green) + (0.0722 * this.blue));
  }
}
