package ImageCommands.ImageOrientation;

import ImageCommands.ImageCommand;
import java.io.File;

/**
 *  a{@code ImageCommands.ImageOrientation.ImageOrientation.VerticalFlip} represents the class that will flip image vertically.
 */
public class VerticalFlip implements ImageOrientation {
  File in;
  File out;

  public VerticalFlip(File in, String name) {
    this.in = in;
    this.out = new File(name);
  }
  @Override
  public int[] process(int... inputs) {

    return new int[0];
  }

  @Override
  public File output() {
    return this.out;
  }
}
