package ImageCommands.ImageOrientation;

import ImageCommands.ImageCommand;
import java.io.File;

/**
 * a {@code ImageCommands.ImageOrientation.ImageOrientation.HorizontalFlip} represents the flipping of an image horizontally.
 */
public class HorizontalFlip implements ImageOrientation {
  File in;
  File out;

  public HorizontalFlip(File in, String name) {
    this.in = in;
    this.out = new File(name);
  }
  @Override
  public int[] process(int... inputs) {

    return new int[0];
  }

  @Override
  public File output() {
    return this.out;
  }
}
