package ImageCommands.ImageOrientation;

import ImageCommands.ImageCommand;
import java.io.File;

/**
 * An Interface for ImageCommands that specifically orient an image differently.
 * AKA moving position of pixels in an image.
 */
public interface ImageOrientation extends ImageCommand {

  /**
   * The Image Orientation Implementations will orient or change the positions of the pixels, we
   * need to output the pixel is some way, therefore this method outputs the augmented file.
   * @return File that has all the changes made
   */
  public File output();
}
