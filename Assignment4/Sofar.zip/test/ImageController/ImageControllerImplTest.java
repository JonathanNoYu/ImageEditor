package ImageController;

import ImageModel.ImageModel;
import ImageView.ImageView;
import org.junit.Test;

public class ImageControllerImplTest {
  ImageController controller1;
  ImageController controller2;
  ImageController controller3;
  ImageController controller4;
  ImageView view1;
  ImageView view2;
  ImageModel model1;
  ImageModel model2;

  @Test
  public void processImage() {
  }

  @Test
  public void testInvalidControllers() {
    try {
      this.controller1 = new ImageControllerImpl(null, );
    }
  }
}